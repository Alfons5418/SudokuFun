function isSafe(board, row, col, num) {
    for (let x = 0; x < 9; x++) {
        if (board[row][x] === num || board[x][col] === num ||
            board[3 * Math.floor(row / 3) + Math.floor(x / 3)]
                 [3 * Math.floor(col / 3) + (x % 3)] === num)
            return false;
    }
    return true;
}

function solveSudoku(board) {
    for (let row = 0; row < 9; row++) {
        for (let col = 0; col < 9; col++) {
            if (board[row][col] === 0) {
                for (let num = 1; num <= 9; num++) {
                    if (isSafe(board, row, col, num)) {
                        board[row][col] = num;
                        if (solveSudoku(board)) return true;
                        board[row][col] = 0;
                    }
                }
                return false;
            }
        }
    }
    return true;
}

function fillBlock(board, row, col) {
    let nums = shuffle([1, 2, 3, 4, 5, 6, 7, 8, 9]);
    for (let i = 0; i < 3; i++) {
        for (let j = 0; j < 3; j++) {
            board[row + i][col + j] = nums.pop();
        }
    }
}

function fillDiagonalBlocks(board) {
    for (let i = 0; i < 9; i += 3) {
        fillBlock(board, i, i);
    }
}

function shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}

function generateFullBoard() {
    const board = Array.from({ length: 9 }, () => Array(9).fill(0));
    fillDiagonalBlocks(board);
    solveSudoku(board);
    return board;
}

function createPuzzle(fullBoard, holes = 45) {
    const puzzle = fullBoard.map(row => row.slice());
    let count = 0;
    while (count < holes) {
        const row = Math.floor(Math.random() * 9);
        const col = Math.floor(Math.random() * 9);
        if (puzzle[row][col] !== 0) {
            puzzle[row][col] = 0;
            count++;
        }
    }
    return puzzle;
}

function generateSudoku() {
    const board = document.getElementById('sudoku-board');
    board.innerHTML = '';
    const fullBoard = generateFullBoard();
    const puzzle = createPuzzle(fullBoard);

    for (let i = 0; i < 9; i++) {
        for (let j = 0; j < 9; j++) {
            const input = document.createElement('input');
            input.maxLength = 1;
            if (puzzle[i][j] !== 0) {
                input.value = puzzle[i][j];
                input.disabled = true;
                input.style.backgroundColor = '#ddd';
            }
            board.appendChild(input);
        }
    }
}

window.onload = generateSudoku;
